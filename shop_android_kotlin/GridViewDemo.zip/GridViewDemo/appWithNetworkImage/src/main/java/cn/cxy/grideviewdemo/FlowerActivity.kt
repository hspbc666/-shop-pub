package cn.cxy.grideviewdemo

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.GridView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_flower.*
import java.util.*

class FlowerActivity : AppCompatActivity() {
    //    private var dataList = ArrayList<Flower>()
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flower)

        var dataList = prepareDataList()

        val flowerAdapter = FlowerAdapter(this, dataList)
        gridView.adapter = flowerAdapter
        gridView.setOnItemClickListener { _, _, position, _ -> toast(dataList[position].flowerName!!) }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun prepareDataList(): ArrayList<Flower> {
        val flowerData = ArrayList<Flower>()

        //1st Item
        var flower = Flower()
        flower.flowerName = "Alyssum"
        flower.imagePath =
            "https://c-ssl.duitang.com/uploads/item/201609/02/20160902173720_ZBYrP.jpeg"
        flowerData.add(flower)

        //2nd Item
        flower = Flower()
        flower.flowerName = "Daisy"
        flower.imagePath =
            "https://c-ssl.duitang.com/uploads/item/201608/31/20160831074631_swUVj.thumb.700_0.jpeg"
        flowerData.add(flower)


        //3rd Item
        flower = Flower()
        flower.flowerName = "Jasmine"
        flower.imagePath =
            "https://c-ssl.duitang.com/uploads/item/201608/31/20160831070405_AdC5E.thumb.700_0.png"
        flowerData.add(flower)


        //4th Item
        flower = Flower()
        flower.flowerName = "Lily"
        flower.imagePath =
            "https://c-ssl.duitang.com/uploads/item/201608/31/20160831070342_KQ4Ry.thumb.700_0.jpeg"
        flowerData.add(flower)


        //5th Item
        flower = Flower()
        flower.flowerName = "Poppy"
        flower.imagePath =
            "https://c-ssl.duitang.com/uploads/item/201608/31/20160831070322_eTjat.thumb.700_0.jpeg"
        flowerData.add(flower)


        //6th Item
        flower = Flower()
        flower.flowerName = "Rose"
        flower.imagePath =
            "https://c-ssl.duitang.com/uploads/item/201608/31/20160831070305_fPQt5.thumb.700_0.jpeg"
        flowerData.add(flower)
        return flowerData
    }
}