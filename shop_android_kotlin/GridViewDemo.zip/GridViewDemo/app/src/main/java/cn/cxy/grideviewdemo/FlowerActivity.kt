package cn.cxy.grideviewdemo

import android.os.Bundle
import android.view.View
import android.widget.GridView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_flower.*
import java.util.*

class FlowerActivity : AppCompatActivity() {
    var dataList = ArrayList<Flower>()
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flower)

        dataList = prepareDataList()

        val flowerAdapter = FlowerAdapter(this, dataList)
        gridView.adapter = flowerAdapter
        gridView.setOnItemClickListener { _, _, position, _ -> toast(dataList[position].flowerName!!) }
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun prepareDataList(): ArrayList<Flower> {
        val flowerData = ArrayList<Flower>()

        //1st Item
        var flower = Flower()
        flower.flowerName = "Alyssum"
        flower.imagePath = R.drawable.image1
        flowerData.add(flower)

        //2nd Item
        flower = Flower()
        flower.flowerName = "Daisy"
        flower.imagePath = R.drawable.image2
        flowerData.add(flower)

        //3rd Item
        flower = Flower()
        flower.flowerName = "Jasmine"
        flower.imagePath = R.drawable.image3
        flowerData.add(flower)

        //4th Item
        flower = Flower()
        flower.flowerName = "Lily"
        flower.imagePath = R.drawable.image1
        flowerData.add(flower)

        //5th Item
        flower = Flower()
        flower.flowerName = "Poppy"
        flower.imagePath = R.drawable.image2
        flowerData.add(flower)

        //6th Item
//        flower = Flower()
//        flower.flowerName = "Rose"
//        flower.imagePath = R.drawable.image3
//        flowerData.add(flower)
        return flowerData
    }
}