package cn.cxy.grideviewdemo

class Flower {
    var flowerName: String? = null
    var imagePath = 0
}